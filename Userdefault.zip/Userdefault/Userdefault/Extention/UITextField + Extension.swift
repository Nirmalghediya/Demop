//
//  UITextField + Extension.swift
//  Userdefault
//
//  Created by Nirmal Ghediya on 18/01/26.
//

import Foundation
import UIKit


extension UITextField {
    func applyPlaceholder(textfield:UITextField,placeholder:String){
       
        textfield.placeholder = placeholder
        let attributes: [NSAttributedString.Key: Any] = [
            .foregroundColor: UIColor(hex: "232323").withAlphaComponent(0.5),
        ]

        textfield.attributedPlaceholder = NSAttributedString(string: textfield.placeholder ?? "", attributes: attributes)
    }
}
