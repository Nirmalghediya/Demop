//
//  UIButton + Extension.swift
//  Userdefault
//
//  Created by Nirmal Ghediya on 18/01/26.
//

import Foundation
import UIKit

extension UIButton {
    func makeroundButton(){
        layer.cornerRadius = layer.frame.height / 2
    }
    
    func applyCornerRedius(_ cornerRadius: CGFloat) {
        layer.cornerRadius = cornerRadius
        layer.masksToBounds = true
    }
    
}
