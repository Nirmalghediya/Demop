//
//  UIImageView.swift
//  Userdefault
//
//  Created by Nirmal Ghediya on 18/01/26.
//

import UIKit

extension UIImage {
    func toData() -> Data? {
        jpegData(compressionQuality: 0.8)
    }
}

extension UIView {
    func textfieldView(color: UIColor = UIColor(hex: "232323").withAlphaComponent(0.7)){
        self.backgroundColor = .clear
        self.layer.borderWidth = 1.0
        self.layer.borderColor = color.cgColor
        self.layer.cornerRadius = 12
        self.layer.masksToBounds = true
    }
    
    
}

extension UIImageView {
    func makeroundImageView(){
        self.contentMode = .scaleAspectFill
        self.layer.cornerRadius = self.frame.height / 2
    }
}
