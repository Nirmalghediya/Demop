//
//  NSObject + Class.swift
//  Userdefault
//
//  Created by Nirmal Ghediya on 18/01/26.
//

import Foundation
public extension NSObject {
    
    var className: String {
        String(describing: type(of: self)).components(separatedBy: ".").first!
    }
    
    class var className: String {
        String(describing: self).components(separatedBy: ".").first!
    }
}
