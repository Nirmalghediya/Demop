//
//  ProductTVCell.swift
//  Userdefault
//
//  Created by Nirmal Ghediya on 18/01/26.
//

import UIKit

class ProductTVCell: UITableViewCell {

    @IBOutlet weak var BGView: UIView! {
        didSet {
            BGView.layer.cornerRadius = 12
        }
    }
    
    @IBOutlet weak var imgProduct: UIImageView!{
        didSet {
            imgProduct.layer.cornerRadius = 12
            imgProduct.contentMode = .scaleAspectFill
        }
    }
    
    @IBOutlet weak var lblTitle: UILabel!{
        didSet {
            lblTitle.font = AppTextStyle.body
        }
    }
    
    @IBOutlet weak var lblPrice: UILabel!{
        didSet {
            lblPrice.font = AppTextStyle.body
        }
    }
    
    @IBOutlet weak var lblDescription: UILabel!{
        didSet {
            lblDescription.font = AppTextStyle.caption
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configure(with product: Product) {
            lblTitle.text = product.title
            lblDescription.text = product.productDescription
            lblPrice.text = "$\(product.price)"

            if let data = product.imageData {
                imgProduct.image = UIImage(data: data)
            }
        }
    
}
