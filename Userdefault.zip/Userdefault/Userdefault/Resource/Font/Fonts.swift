//
//  Fonts.swift
//  Userdefault
//
//  Created by Nirmal Ghediya on 18/01/26.
//

import Foundation
import UIKit

enum FontWeight {
    case bold
    case semibold
    case medium
    case regular
    case light
}

protocol FontFamily {
    static func fontName(for weight: FontWeight) -> String
}

enum Montserrat: FontFamily {
    static func fontName(for weight: FontWeight) -> String {
        switch weight {
        case .bold:
            return "Montserrat-Bold"
        case .semibold:
            return "Montserrat-SemiBold"
        case .medium:
            return "Montserrat-Medium"
        case .regular:
            return "Montserrat-Regular"
        case .light:
            return "Montserrat-Light"
        }
    }
}

struct AppFont<F: FontFamily> {
    static func font(
        _ weight: FontWeight,
        size: CGFloat
    ) -> UIFont {
        UIFont(
            name: F.fontName(for: weight),
            size: size
        ) ?? .systemFont(ofSize: size)
    }
}

enum AppTextStyle {
    static let title = AppFont<Montserrat>.font(.bold, size: 24)
    static let subtitle = AppFont<Montserrat>.font(.semibold, size: 18)
    static let body = AppFont<Montserrat>.font(.regular, size: 14)
    static let caption = AppFont<Montserrat>.font(.light, size: 12)
}
