//
//  RegisterNibView.swift
//  Userdefault
//
//  Created by Nirmal Ghediya on 18/01/26.
//

import Foundation
import UIKit

open class RegisterNibView: UIView {
    
    // MARK: - Properties

    @IBOutlet
    public var contentView: UIView!
    
    // MARK: - Lifecycle

    override public init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    /// override for init
    open func commonInit() {
        
        guard let view = loadViewFromNib() else {
            return
        }
        
        view.frame = self.bounds
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.backgroundColor = .clear
        self.addSubview(view)
        
        self.contentView = view
    }
    
    private func loadViewFromNib() -> UIView? {
        let bundle = Bundle(for: type(of: self))
        let nib = UINib(nibName: self.className, bundle: bundle)
        return nib.instantiate(withOwner: self, options: nil).first as? UIView
    }
    
    // Utility
    
    func getAttributedString(fullText: String, highlightedText: String) -> NSAttributedString {
        
        let attributedText = NSMutableAttributedString(string: fullText)
        let range = (fullText as NSString).range(of: highlightedText)
       // attributedText.addAttributes([.foregroundColor: Asset.Colors.paleTeal.color], range: range)
        return attributedText
    }
}
