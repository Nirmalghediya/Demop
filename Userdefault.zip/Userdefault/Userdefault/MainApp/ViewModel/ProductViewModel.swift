//
//  ProductViewModel.swift
//  Userdefault
//
//  Created by Nirmal Ghediya on 18/01/26.
//

import Foundation
import UIKit
import CoreData


final class ProductViewModel {
    
    func saveProduct(
        title: String,
        description: String,
        price: Double,
        image: UIImage
    ) {
        let context = CoreDataManager.shared.context
        let product = Product(context: context)

        product.title = title
        product.productDescription = description
        product.price = price
        product.imageData = image.toData()

        CoreDataManager.shared.save()
    }
    
    func fetchProducts() -> [Product] {
        let request: NSFetchRequest<Product> = Product.fetchRequest()
        request.sortDescriptors = [
            NSSortDescriptor(key: "title", ascending: true)
        ]

        return (try? CoreDataManager.shared.context.fetch(request)) ?? []
    }


    
}
