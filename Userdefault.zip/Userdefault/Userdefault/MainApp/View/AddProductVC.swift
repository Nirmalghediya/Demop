//
//  AddProductVC.swift
//  Userdefault
//
//  Created by Nirmal Ghediya on 18/01/26.
//

import UIKit

protocol AddProductDelegate: AnyObject {
    func addproduct()
}

class AddProductVC: UIViewController {

    @IBOutlet weak var lblname: UILabel!
    
    @IBOutlet weak var lblPrice: UILabel!
    
    @IBOutlet weak var lblDescription: UILabel!
    
    @IBOutlet weak var txtname: UITextField!
    
    @IBOutlet weak var txtprice: UITextField!
    
    @IBOutlet weak var txtDescription: UITextView!
    
    @IBOutlet weak var btnAdd: UIButton!
    
    @IBOutlet weak var nameView: UIView!
    
    @IBOutlet weak var priceView: UIView!
    
    @IBOutlet weak var descriptionView: UIView!
    
    @IBOutlet weak var imgProfile: UIImageView!
    
    @IBOutlet weak var lblViewTitle: UILabel!
    
    let vm = ProductViewModel()
    weak var delegate: AddProductDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
    }
    
    @IBAction func btnAdd(_ sender: Any) {
        
        guard validateInputs() else { return }

        let name = txtname.text!
        let price = Double(txtprice.text!)!
        let description = txtDescription.text!
        let image = imgProfile.image!
        
        vm.saveProduct(title: name, description: description, price: price, image: image)
        showAlert("Product added successfully", isSuccess: true)
    }
    
    @IBAction func btnImage(_ sender: Any) {
        let picker = UIImagePickerController()
            picker.delegate = self
            picker.sourceType = .photoLibrary
            picker.allowsEditing = false
            present(picker, animated: true)
    }
    
    @IBAction func btnBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    
    
    private func setupUI() {
        lblname.font = AppTextStyle.subtitle
        lblPrice.font = AppTextStyle.subtitle
        lblDescription.font = AppTextStyle.subtitle
        lblViewTitle.font = AppTextStyle.subtitle
        txtprice.keyboardType = .decimalPad
        btnAdd.applyCornerRedius(12)
        imgProfile.makeroundImageView()
        nameView.textfieldView()
        priceView.textfieldView()
        descriptionView.textfieldView()
        imgProfile.image = UIImage(systemName: "person.circle.fill")
        txtDescription.delegate = self
        txtDescription.text = "Write here..."
        txtDescription.textColor = UIColor(hex: "232323").withAlphaComponent(0.5)
        
    }
    
    private func showAlert(_ message: String, isSuccess: Bool = false) {
        let alert = UIAlertController(
            title: isSuccess ? "Success" : "Error",
            message: message,
            preferredStyle: .alert
        )

        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
            if isSuccess {
                self.delegate?.addproduct()
                self.navigationController?.popViewController(animated: true)
            }
        })

        present(alert, animated: true)
    }

    private func validateInputs() -> Bool {

        guard let name = txtname.text?.trimmingCharacters(in: .whitespaces),
              !name.isEmpty else {
            showAlert("Please enter product name")
            return false
        }

        guard let priceText = txtprice.text,
              let price = Double(priceText),
              price > 0 else {
            showAlert("Please enter valid price")
            return false
        }

        let descriptionText = txtDescription.text.trimmingCharacters(in: .whitespaces)
        if descriptionText.isEmpty || descriptionText == "Write here..." {
            showAlert("Please enter description")
            return false
        }
        
        if imgProfile.image == UIImage(systemName: "person.circle.fill") {
            showAlert("Please select product image")
            return false
        }

        return true
    }

}

extension AddProductVC: UITextViewDelegate {
    func textViewDidBeginEditing(_ textView: UITextView) {
            if textView.text == "Write here..." {
                textView.text = ""
                textView.textColor = UIColor(hex: "232323")
            }
    }

    func textViewDidEndEditing(_ textView: UITextView) {
            if textView.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                textView.text = "Write here..."
                textView.textColor = UIColor(hex: "232323").withAlphaComponent(0.5)
            }
    }
}

extension AddProductVC:
                    UIImagePickerControllerDelegate,
                    UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {

        if let image = info[.originalImage] as? UIImage {
            imgProfile.image = image
        }

        dismiss(animated: true)
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true)
    }

    
}
