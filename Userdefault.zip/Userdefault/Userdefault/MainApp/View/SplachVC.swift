//
//  SplachVC.swift
//  Userdefault
//
//  Created by Nirmal Ghediya on 18/01/26.
//

import UIKit

class SplachVC: UIViewController {

    @IBOutlet weak var lblTitle: UILabel! {
        didSet {
            lblTitle.font = AppTextStyle.title
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3) { [self] in
            let storyboard = UIStoryboard(name: "Home", bundle: nil)
            if let mainTabBarVC = storyboard.instantiateViewController(withIdentifier: "HomeVC") as? HomeVC {
            let navigationController = UINavigationController(rootViewController: mainTabBarVC)
            (UIApplication.shared.connectedScenes.first?.delegate as? UIWindowSceneDelegate)?.window??.rootViewController = navigationController
            }
        }
    }
    

}
