//
//  HomeVC.swift
//  Userdefault
//
//  Created by Nirmal Ghediya on 18/01/26.
//

import UIKit

class HomeVC: UIViewController {

    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var tableView: UITableView!
    
    let vm = ProductViewModel()
    private var products: [Product] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        self.setupTableView()
        self.fetchData()
    }
    
    func fetchData() {
        products = vm.fetchProducts()
        tableView.reloadData()
    }
    private func setupTableView(){
        //ProductTVCell
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "ProductTVCell", bundle: nil), forCellReuseIdentifier: "ProductTVCell")
    }
    
    @IBAction func btnAdd(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "AddProductVC") as! AddProductVC
        vc.delegate = self
        navigationController?.pushViewController(vc, animated: true)
    }
    

}

extension HomeVC: AddProductDelegate {
    func addproduct() {
        self.fetchData()
    }
    
    
}

extension HomeVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTVCell", for: indexPath) as! ProductTVCell
        cell.selectionStyle = .none
        let product = products[indexPath.row]
        cell.configure(with: product)
        return cell
    }
    
    
}
